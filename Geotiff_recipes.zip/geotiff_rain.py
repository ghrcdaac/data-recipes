#######################################################################
# geotiff_rain.py                                                     #
#                                                                     #
#  This code converts total column water vapor (TotalColWaterVapor)   #
#    in the AMSR-2 NRT Rain product in HDF-EOS5 format to GeoTiff,    #
#    with the use of GIBS color scheme for the variable.              #
#                                                                     #
# Use remapSwath() to remap data array to (epsg 4326) projection       #
#    i.e. WGS84.  orient='slant' option puts the  projected GeoTiff    #
#    the slanted swath of the original data that requires less         #
#    not-value fill-in pixels, i.e. upscaling.                         #
#                                                                     #
#  User should use <latRange> to select the latitude range of the     #
#    swath (based on the center line of the swath) to be converted to #
#    geotiff. For various reasons, it is recommended the range to be  #
#    limited to any numbers between -75 and 75 degrees.               #
#                                                                     #
#  The output Geotiff imagery "looks" retangular as GeoTiff imageries #
#    always are before loaded to a map, i.e. it will appear slanted   #
#       along the swath direction with map projection.                #
#                                                                     #
#  Input: AMSR-2 NRT Rain file                                        #
#  Output: GeoTIFF file in of selected latitude range of the Rain     #
#          product swath in epsg4326 (WGS 84) projection with given   #
#          geotransformation parameters in the output file            #    
#                                                                     #
#  Required Python packages:                                          #
#      numpy, scipy, pyproj, gdal and GHRC's GIBScolors_utils         #
#                                                                     #
#  Notes:                                                             #
#    Original data type for 'TotalColWaterVapor' is byte (-127 to 128)#
#    It's converted to unsigned byte (0-255) for the GeoTiff output   #
#                                                                     #
#    User can set <useGIBScolors> to True/False to elect use of GIBS  #
#    color scheme or not.                                             #
#    In the case of useGIBScolors=True, <gibsMapDir> the location     #
#    of GIBS color scheme files needs to be provided                  #
#                                                                     #
#  By Y. WU of AMSR team @GHRC, Aug 2021                             #
#######################################################################

import numpy as np
from osgeo import gdal, osr
from ConvSwath import remapSwath
from GIBScolors_utils import *

#---- File name and initial run parameters
h5file = 'C:/Users/lwang/Documents/AMSR/data/AMSR_U2_L2_Rain_R01_202106230930_A.he5'
fileParts =h5file.split('_')
tstr = fileParts[-2]

#--- latitude range for the SWATHS data to be converted to GeoTiff
#    inclusion of higher latitudes could greatly increase upscaling, as well as process time 
latRange = [-60,60]

#--- name of variable to be converted
vname = 'TotalColWaterVapor'

#--- fillv for the variable in the original AMSR file 
fillv = -99

#--- Option to use GIBS color scheme
useGIBScolors = True
gibsMapDir='C:/Users/lwang/Documents/AMSR/colormaps/' #<-- ends with '/' for colorm files parsing

#--- Open hdf5 with GDAL and get data attributes
hdf_ds = gdal.Open(h5file, gdal.GA_ReadOnly)
dslist = hdf_ds.GetSubDatasets()
ds1 = [s[0].split('//HDFEOS/SWATHS/')[-1] for s in dslist] # include lat, lon

#---get data from the original hdf dataset
for ii, a in enumerate(ds1):
    if(vname in a): isubset = ii
varband = gdal.Open(hdf_ds.GetSubDatasets()[isubset][0], gdal.GA_ReadOnly)
bandArr0 = varband.ReadAsArray()

#---get (lat, lon) for the grid and geotransform info
for ii, a in enumerate(ds1):
    if('/Lat' in a): ilat = ii
    if('/Lon' in a): ilon = ii

Lat = gdal.Open(hdf_ds.GetSubDatasets()[ilat][0], gdal.GA_ReadOnly)
Lon = gdal.Open(hdf_ds.GetSubDatasets()[ilon][0], gdal.GA_ReadOnly)
Lat = Lat.ReadAsArray()
Lon = Lon.ReadAsArray()

#---remap data array and obtain geotransform parameters
bandArr, geotransform = remapSwath(bandArr0, Lon, Lat, latRange, fillv=fillv, orient='slant')

NY,NX = bandArr.shape

#---fix band description for output img size/shape
banddsc = vname + '('+str(NY)+'x'+str(NX)+') not org.'

#-----------------------------------------------
#- set driver, datatype, projection, and       -
#-  geotransformation for output geotiff       -
#-----------------------------------------------
#<--- output geotiff file name
TIFFpath= 'C:/Users/lwang/Documents/AMSR/Data_Out/'+vname+'_'+tstr+'.tif'
driver = gdal.GetDriverByName('GTiff')
out_ds = driver.Create(TIFFpath,
                       NX, NY,
                       1,
                       gdal.GDT_Byte)


OutPrj = osr.SpatialReference()
OutPrj.ImportFromEPSG(4326)  #<--use (lat,lon)
out_ds.SetProjection(OutPrj.ExportToWkt())
out_ds.SetGeoTransform(geotransform)

#---activate output band
outBand = out_ds.GetRasterBand(1)
notVal = 255

#--set not-value and data type
bandArr[bandArr==fillv] = notVal


#---make geotiff with GIBS colors if so opted
outBand = out_ds.GetRasterBand(1)
scaleFC = {}
if(useGIBScolors): 
    gibsColors = gibsScheme(gibsMapDir, 'Rain', vname, scaleFC)
    if gibsColors:
        colors = colorTable(gibsColors, 255, scaleFC, verb=False)
        outBand.SetColorTable(colors)
        outBand.SetColorInterpretation(gdal.GCI_PaletteIndex)

#---writing geotiff band
bandArr = bandArr.astype('uint8')
outBand.WriteArray(bandArr)
outBand.SetDescription(banddsc)
outBand.SetNoDataValue(notVal)

outBand = None
out_ds = None  
print('Save to',TIFFpath,'\n')
